# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2020-present Fewtarius

# Source predefined functions and variables
. /etc/profile

# Show splash screen
/emuelec/scripts/show_splash.sh shutdown

shutdown $*
